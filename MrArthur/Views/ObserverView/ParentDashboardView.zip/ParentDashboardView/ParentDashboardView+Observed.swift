//
//  ParentDashboardView+Observed.swift
//  MrArthur
//
//  Created by IPS-157 on 26/07/22.
//

import Foundation
import SwiftUI

extension ParentDashboardView{
    class Observed:ObservableObject{
    }
}
